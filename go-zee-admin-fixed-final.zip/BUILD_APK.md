# GO ZEE Admin - APK build

This project is prepared for a GitHub Actions debug APK build.

Fixes included:
- Removed the KSP plugin and KSP-only compiler dependencies because the app source does not use Room/Moshi generated code.
- Removed the custom debug.keystore signing configuration; debug builds use Android/Gradle's standard debug signing.
- Kept Google Services in WARN mode so a missing `google-services.json` does not stop the debug build.
- Added `.github/workflows/build-apk.yml` which finds the project ZIP in the repository root, extracts it, and builds `app-debug.apk`.
- Java 17 is used for the Android build.

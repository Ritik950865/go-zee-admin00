package com.example.model

enum class RideStatus(val label: String) {
  ONGOING("In-Transit"),
  COMPLETED("Completed"),
  CANCELLED("Cancelled"),
  SEARCHING("Finding Captain")
}

enum class VehicleType(val label: String) {
  BIKE_TAXI("Bike Taxi"),
  QUICK_DELIVERY("Quick Parcel"),
  EV_SCOOTER("EV Scoot")
}

enum class PaymentMethod(val label: String) {
  UPI("UPI / QR"),
  CASH("Cash"),
  GO_ZEE_WALLET("GoZee Wallet")
}

data class RideItem(
  val id: String,
  val riderName: String,
  val riderPhone: String,
  val captainName: String,
  val captainPhone: String,
  val pickupAddress: String,
  val dropAddress: String,
  val fare: Double,
  val status: RideStatus,
  val vehicleType: VehicleType,
  val distanceKm: Double,
  val timeAgo: String,
  val paymentMethod: PaymentMethod
)

enum class KycStatus(val label: String) {
  VERIFIED("Verified"),
  PENDING("Pending KYC"),
  REJECTED("Suspended")
}

data class Captain(
  val id: String,
  val name: String,
  val phone: String,
  val bikeModel: String,
  val registrationNumber: String,
  val rating: Double,
  val totalRides: Int,
  val earningsToday: Double,
  val kycStatus: KycStatus,
  val isOnline: Boolean,
  val vehicleType: VehicleType
)

data class DashboardMetrics(
  val totalRevenue: Double = 48250.0,
  val revenueGrowth: String = "+14.2%",
  val activeCaptains: Int = 142,
  val totalTripsToday: Int = 1284,
  val activeBookings: Int = 28,
  val completionRate: String = "96.4%"
)

data class FareConfig(
  val baseFare: Double = 25.0,
  val perKmRate: Double = 11.0,
  val commissionPct: Int = 15,
  val surgeMultiplier: Float = 1.2f,
  val nightChargeActive: Boolean = false,
  val sosHelpline: String = "1800-425-9333"
)

data class BroadcastAlert(
  val id: String,
  val title: String,
  val message: String,
  val time: String,
  val isUrgent: Boolean = false
)

package com.example.ui.screens.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBike
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BroadcastAlert
import com.example.model.DashboardMetrics
import com.example.model.FareConfig
import com.example.model.RideItem
import com.example.model.RideStatus
import com.example.ui.components.MetricStatCard
import com.example.ui.components.RideCard
import com.example.ui.theme.GoZeeBlack
import com.example.ui.theme.GoZeeGreen
import com.example.ui.theme.GoZeeRed
import com.example.ui.theme.GoZeeSurface
import com.example.ui.theme.GoZeeTextMuted
import com.example.ui.theme.GoZeeTextPrimary
import com.example.ui.theme.GoZeeTextSecondary
import com.example.ui.theme.GoZeeYellow

@Composable
fun DashboardOverviewTab(
  metrics: DashboardMetrics,
  fareConfig: FareConfig,
  liveRides: List<RideItem>,
  alerts: List<BroadcastAlert>,
  onUpdateSurge: (Float) -> Unit,
  onOpenDispatch: () -> Unit,
  onOpenBroadcast: () -> Unit,
  onRideClick: (RideItem) -> Unit,
  onCompleteRide: (String) -> Unit,
  onCancelRide: (String) -> Unit,
  onViewAllRides: () -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(4.dp))
      // Fleet Live Status Banner
      Card(
        modifier = Modifier.fillMaxWidth().testTag("live_status_banner"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = GoZeeBlack)
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(GoZeeGreen)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "FLEET DISPATCH ACTIVE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = GoZeeYellow,
                letterSpacing = 1.sp
              )
              Text(
                text = "${metrics.activeCaptains} Captains Online • ${metrics.activeBookings} Live Rides",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
              )
            }
          }
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(GoZeeYellow)
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Text(
              text = "${fareConfig.surgeMultiplier}x SURGE",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = GoZeeBlack
            )
          }
        }
      }
    }

    // 4 KPI Metric Cards in 2 rows
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          MetricStatCard(
            title = "Today's Gross",
            value = "₹${String.format("%.0f", metrics.totalRevenue)}",
            subtitle = metrics.revenueGrowth,
            icon = Icons.Filled.AttachMoney,
            accentColor = GoZeeGreen,
            modifier = Modifier.weight(1f)
          )
          MetricStatCard(
            title = "Captains Online",
            value = "${metrics.activeCaptains}",
            subtitle = "Active Fleet",
            icon = Icons.Filled.TwoWheeler,
            accentColor = GoZeeBlack,
            modifier = Modifier.weight(1f)
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          MetricStatCard(
            title = "Trips Completed",
            value = "${metrics.totalTripsToday}",
            subtitle = metrics.completionRate,
            icon = Icons.Filled.CheckCircle,
            accentColor = Color(0xFF3B82F6),
            modifier = Modifier.weight(1f)
          )
          MetricStatCard(
            title = "Live In-Transit",
            value = "${metrics.activeBookings}",
            subtitle = "Active Trips",
            icon = Icons.Filled.Speed,
            accentColor = Color(0xFFF59E0B),
            modifier = Modifier.weight(1f)
          )
        }
      }
    }

    // Quick Surge Multiplier Control Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth().testTag("surge_control_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = GoZeeSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.Bolt, contentDescription = "Surge", tint = GoZeeYellow, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Dynamic Surge Pricing",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = GoZeeTextPrimary
              )
            }
            Text(
              text = "${String.format("%.1fx", fareConfig.surgeMultiplier)} Current",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = GoZeeBlack
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "Select city surge mode to automatically adjust captain rates and trip prices:",
            fontSize = 12.sp,
            color = GoZeeTextSecondary
          )

          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            val surgeOptions = listOf(
              1.0f to "1.0x Normal",
              1.2f to "1.2x Busy",
              1.5f to "1.5x Rain",
              2.0f to "2.0x Peak"
            )
            surgeOptions.forEach { (factor, label) ->
              FilterChip(
                selected = kotlin.math.abs(fareConfig.surgeMultiplier - factor) < 0.05f,
                onClick = { onUpdateSurge(factor) },
                label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = GoZeeYellow,
                  selectedLabelColor = GoZeeBlack
                ),
                modifier = Modifier.weight(1f).testTag("surge_button_${factor}")
              )
            }
          }
        }
      }
    }

    // Quick Command Actions
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = onOpenDispatch,
          modifier = Modifier.weight(1f).height(46.dp).testTag("quick_dispatch_button"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = GoZeeYellow, contentColor = GoZeeBlack)
        ) {
          Icon(Icons.Default.Add, contentDescription = "Dispatch", modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Dispatch Ride", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }

        Button(
          onClick = onOpenBroadcast,
          modifier = Modifier.weight(1f).height(46.dp).testTag("quick_broadcast_button"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = GoZeeBlack, contentColor = Color.White)
        ) {
          Icon(Icons.Default.Campaign, contentDescription = "Broadcast", modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Broadcast", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
      }
    }

    // Live In-Transit Trips
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Live Active Trips",
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = GoZeeTextPrimary
        )
        OutlinedButton(
          onClick = onViewAllRides,
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("View All", fontSize = 12.sp, color = GoZeeBlack)
        }
      }
    }

    val liveTripList = liveRides.filter { it.status == RideStatus.ONGOING }.take(3)
    if (liveTripList.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = GoZeeSurface)
        ) {
          Box(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            contentAlignment = Alignment.Center
          ) {
            Text("No ongoing trips at this moment.", color = GoZeeTextMuted, fontSize = 13.sp)
          }
        }
      }
    } else {
      items(liveTripList, key = { it.id }) { ride ->
        RideCard(
          ride = ride,
          onClick = { onRideClick(ride) },
          onComplete = { onCompleteRide(ride.id) },
          onCancel = { onCancelRide(ride.id) }
        )
      }
    }

    // Recent Broadcasts
    item {
      Text(
        text = "Fleet Broadcast Alerts",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        color = GoZeeTextPrimary,
        modifier = Modifier.padding(top = 8.dp)
      )
    }

    items(alerts, key = { it.id }) { alert ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (alert.isUrgent) Color(0xFFFEF2F2) else GoZeeSurface
        )
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.Top
        ) {
          Icon(
            imageVector = Icons.Default.Campaign,
            contentDescription = "Alert",
            tint = if (alert.isUrgent) GoZeeRed else GoZeeYellow,
            modifier = Modifier.size(20.dp).padding(top = 2.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = alert.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (alert.isUrgent) GoZeeRed else GoZeeTextPrimary
              )
              Text(
                text = alert.time,
                fontSize = 10.sp,
                color = GoZeeTextMuted
              )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = alert.message,
              fontSize = 12.sp,
              color = GoZeeTextSecondary
            )
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AdminTab
import com.example.ui.AdminViewModel
import com.example.ui.components.BroadcastDialog
import com.example.ui.components.DispatchRideDialog
import com.example.ui.components.LogoutConfirmDialog
import com.example.ui.components.RideDetailDialog
import com.example.ui.screens.tabs.AnalyticsTab
import com.example.ui.screens.tabs.CaptainsTab
import com.example.ui.screens.tabs.DashboardOverviewTab
import com.example.ui.screens.tabs.FareAndSurgeTab
import com.example.ui.screens.tabs.RidesTab
import com.example.ui.theme.GoZeeBackground
import com.example.ui.theme.GoZeeBlack
import com.example.ui.theme.GoZeeGreen
import com.example.ui.theme.GoZeeSurface
import com.example.ui.theme.GoZeeYellow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(
  viewModel: AdminViewModel,
  onLogout: () -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedTab by viewModel.selectedTab.collectAsState()
  val metrics by viewModel.metrics.collectAsState()
  val fareConfig by viewModel.fareConfig.collectAsState()
  val filteredRides by viewModel.filteredRides.collectAsState()
  val filteredCaptains by viewModel.filteredCaptains.collectAsState()
  val alerts by viewModel.alerts.collectAsState()
  val searchQuery by viewModel.searchQuery.collectAsState()
  val selectedRideFilter by viewModel.selectedRideFilter.collectAsState()
  val selectedKycFilter by viewModel.selectedKycFilter.collectAsState()

  val selectedRideForDetail by viewModel.selectedRideForDetail.collectAsState()
  val showBroadcastDialog by viewModel.showBroadcastDialog.collectAsState()
  val showDispatchDialog by viewModel.showDispatchDialog.collectAsState()
  val showLogoutConfirmDialog by viewModel.showLogoutConfirmDialog.collectAsState()
  val snackbarMsg by viewModel.snackbarMessage.collectAsState()

  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(snackbarMsg) {
    snackbarMsg?.let {
      snackbarHostState.showSnackbar(it)
      viewModel.clearSnackbar()
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = GoZeeBackground,
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(GoZeeYellow),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Filled.TwoWheeler,
                contentDescription = "Logo",
                tint = GoZeeBlack,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "GO ZEE",
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                letterSpacing = 1.sp,
                color = GoZeeBlack
              )
              Text(
                text = "Admin Panel",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF6B7280)
              )
            }
          }
        },
        actions = {
          // Status Pill
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(GoZeeYellow.copy(alpha = 0.3f))
              .padding(horizontal = 8.dp, vertical = 4.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .clip(CircleShape)
                  .background(GoZeeGreen)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "LIVE",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = GoZeeBlack
              )
            }
          }

          // Broadcast icon
          IconButton(
            onClick = { viewModel.setBroadcastDialogVisible(true) },
            modifier = Modifier.testTag("topbar_broadcast_button")
          ) {
            Icon(
              imageVector = Icons.Default.Campaign,
              contentDescription = "Broadcast",
              tint = GoZeeBlack
            )
          }

          // Logout icon
          IconButton(
            onClick = { viewModel.setLogoutConfirmVisible(true) },
            modifier = Modifier.testTag("topbar_logout_button")
          ) {
            Icon(
              imageVector = Icons.Default.Logout,
              contentDescription = "Logout",
              tint = Color(0xFFDC2626)
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = GoZeeSurface,
          titleContentColor = GoZeeBlack
        )
      )
    },
    bottomBar = {
      NavigationBar(
        containerColor = GoZeeSurface,
        tonalElevation = 8.dp
      ) {
        val tabs = listOf(
          AdminTab.OVERVIEW to Icons.Default.Dashboard,
          AdminTab.RIDES to Icons.Default.TwoWheeler,
          AdminTab.CAPTAINS to Icons.Default.People,
          AdminTab.FARES to Icons.Default.Bolt,
          AdminTab.ANALYTICS to Icons.Default.BarChart
        )

        tabs.forEach { (tab, icon) ->
          NavigationBarItem(
            selected = selectedTab == tab,
            onClick = { viewModel.onSelectTab(tab) },
            icon = { Icon(icon, contentDescription = tab.title) },
            label = { Text(tab.title, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = GoZeeBlack,
              selectedTextColor = GoZeeBlack,
              indicatorColor = GoZeeYellow,
              unselectedIconColor = Color(0xFF9CA3AF),
              unselectedTextColor = Color(0xFF9CA3AF)
            ),
            modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
          )
        }
      }
    },
    floatingActionButton = {
      if (selectedTab == AdminTab.OVERVIEW || selectedTab == AdminTab.RIDES) {
        FloatingActionButton(
          onClick = { viewModel.setDispatchDialogVisible(true) },
          containerColor = GoZeeYellow,
          contentColor = GoZeeBlack,
          modifier = Modifier.testTag("fab_dispatch_ride")
        ) {
          Icon(Icons.Default.Add, contentDescription = "Dispatch Ride")
        }
      }
    },
    snackbarHost = { SnackbarHost(snackbarHostState) }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (selectedTab) {
        AdminTab.OVERVIEW -> DashboardOverviewTab(
          metrics = metrics,
          fareConfig = fareConfig,
          liveRides = filteredRides,
          alerts = alerts,
          onUpdateSurge = { viewModel.updateSurge(it) },
          onOpenDispatch = { viewModel.setDispatchDialogVisible(true) },
          onOpenBroadcast = { viewModel.setBroadcastDialogVisible(true) },
          onRideClick = { viewModel.showRideDetail(it) },
          onCompleteRide = { viewModel.completeRide(it) },
          onCancelRide = { viewModel.cancelRide(it) },
          onViewAllRides = { viewModel.onSelectTab(AdminTab.RIDES) }
        )

        AdminTab.RIDES -> RidesTab(
          rides = filteredRides,
          searchQuery = searchQuery,
          selectedStatus = selectedRideFilter,
          onSearchChange = { viewModel.onSearchQueryChange(it) },
          onStatusSelect = { viewModel.onRideFilterChange(it) },
          onRideClick = { viewModel.showRideDetail(it) },
          onCompleteRide = { viewModel.completeRide(it) },
          onCancelRide = { viewModel.cancelRide(it) }
        )

        AdminTab.CAPTAINS -> CaptainsTab(
          captains = filteredCaptains,
          searchQuery = searchQuery,
          selectedKyc = selectedKycFilter,
          onSearchChange = { viewModel.onSearchQueryChange(it) },
          onKycSelect = { viewModel.onKycFilterChange(it) },
          onCaptainClick = { viewModel.showCaptainDetail(it) },
          onToggleOnline = { viewModel.toggleCaptainOnline(it) },
          onApproveKyc = { viewModel.approveCaptain(it) },
          onSuspendCaptain = { viewModel.suspendCaptain(it) }
        )

        AdminTab.FARES -> FareAndSurgeTab(
          fareConfig = fareConfig,
          onSaveRates = { base, perKm, comm, night, helpline ->
            viewModel.updateRates(base, perKm, comm, night, helpline)
          },
          onUpdateSurge = { viewModel.updateSurge(it) }
        )

        AdminTab.ANALYTICS -> AnalyticsTab()
      }
    }
  }

  // Dialogs
  if (showDispatchDialog) {
    DispatchRideDialog(
      onDismiss = { viewModel.setDispatchDialogVisible(false) },
      onDispatch = { rider, phone, pickup, drop, type, dist ->
        viewModel.dispatchRide(rider, phone, pickup, drop, type, dist)
      }
    )
  }

  if (showBroadcastDialog) {
    BroadcastDialog(
      onDismiss = { viewModel.setBroadcastDialogVisible(false) },
      onSend = { title, msg, urgent ->
        viewModel.sendBroadcast(title, msg, urgent)
      }
    )
  }

  selectedRideForDetail?.let { ride ->
    RideDetailDialog(
      ride = ride,
      onDismiss = { viewModel.showRideDetail(null) },
      onComplete = { viewModel.completeRide(ride.id) },
      onCancel = { viewModel.cancelRide(ride.id) }
    )
  }

  if (showLogoutConfirmDialog) {
    LogoutConfirmDialog(
      onDismiss = { viewModel.setLogoutConfirmVisible(false) },
      onConfirm = {
        viewModel.logout()
        onLogout()
      }
    )
  }
}

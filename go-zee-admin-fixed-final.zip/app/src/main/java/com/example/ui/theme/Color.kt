package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GO ZEE Brand Colors from user specification
val GoZeeYellow = Color(0xFFFFD600)
val GoZeeYellowDark = Color(0xFFE5C000)
val GoZeeYellowLight = Color(0xFFFFF3B0)
val GoZeeBlack = Color(0xFF050505)
val GoZeeGreen = Color(0xFF22C55E)
val GoZeeGreenLight = Color(0xFFDCFCE7)
val GoZeeRed = Color(0xFFEF4444)
val GoZeeRedLight = Color(0xFFFEE2E2)
val GoZeeBlue = Color(0xFF3B82F6)
val GoZeeBlueLight = Color(0xFFDBEAFE)

val GoZeeBackground = Color(0xFFF5F5F5)
val GoZeeSurface = Color(0xFFFFFFFF)
val GoZeeSurfaceDark = Color(0xFF161616)
val GoZeeCardDark = Color(0xFF212124)
val GoZeeBorder = Color(0xFFE5E7EB)
val GoZeeTextPrimary = Color(0xFF0F172A)
val GoZeeTextSecondary = Color(0xFF64748B)
val GoZeeTextMuted = Color(0xFF94A3B8)


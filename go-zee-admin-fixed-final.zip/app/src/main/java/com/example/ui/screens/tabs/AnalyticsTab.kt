package com.example.ui.screens.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBike
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoZeeBlack
import com.example.ui.theme.GoZeeGreen
import com.example.ui.theme.GoZeeSurface
import com.example.ui.theme.GoZeeTextMuted
import com.example.ui.theme.GoZeeTextPrimary
import com.example.ui.theme.GoZeeTextSecondary
import com.example.ui.theme.GoZeeYellow

@Composable
fun AnalyticsTab(
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp)
      .testTag("analytics_tab"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Hourly Trip Volume Chart
    Card(
      modifier = Modifier.fillMaxWidth().testTag("hourly_volume_card"),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GoZeeSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Timeline, contentDescription = "Volume", tint = GoZeeBlack, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Hourly Demand Patterns",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = GoZeeTextPrimary
          )
        }
        Text(
          text = "Peak ride request volume distribution across 24 hours",
          fontSize = 12.sp,
          color = GoZeeTextSecondary,
          modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
        )

        // Custom Visual Bar Chart
        val hourlyData = listOf(
          "06-09 AM" to 0.85f,
          "09-12 PM" to 0.95f,
          "12-03 PM" to 0.50f,
          "03-06 PM" to 0.70f,
          "06-09 PM" to 1.00f,
          "09-12 AM" to 0.40f
        )

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(130.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
        ) {
          hourlyData.forEach { (slot, ratio) ->
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Bottom,
              modifier = Modifier.weight(1f)
            ) {
              val isPeak = ratio >= 0.9f
              Box(
                modifier = Modifier
                  .width(26.dp)
                  .height((90 * ratio).dp)
                  .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                  .background(if (isPeak) GoZeeYellow else GoZeeBlack)
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = slot.split(" ")[0],
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = GoZeeTextSecondary
              )
            }
          }
        }
      }
    }

    // Top High-Demand Zones Card
    Card(
      modifier = Modifier.fillMaxWidth().testTag("top_zones_card"),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GoZeeSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.LocationOn, contentDescription = "Zones", tint = Color(0xFFEF4444), modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Top High-Demand Zones",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = GoZeeTextPrimary
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        val zones = listOf(
          Triple("Metro Station & Railway Terminals", "412 trips today", 0.85f),
          Triple("Cyber Tech Park & SEZ Hub", "380 trips today", 0.78f),
          Triple("Koramangala & Indiranagar Dine-Out", "295 trips today", 0.62f),
          Triple("University Campus & Colleges", "197 trips today", 0.45f)
        )

        zones.forEach { (name, count, progress) ->
          Column(modifier = Modifier.padding(vertical = 6.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(name, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = GoZeeTextPrimary)
              Text(count, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoZeeBlack)
            }
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
              progress = { progress },
              modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
              color = GoZeeYellow,
              trackColor = Color(0xFFF3F4F6)
            )
          }
        }
      }
    }

    // Fleet Vehicle Distribution Card
    Card(
      modifier = Modifier.fillMaxWidth().testTag("fleet_distribution_card"),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GoZeeSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.TwoWheeler, contentDescription = "Fleet", tint = GoZeeBlack, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Fleet Vehicle Type Distribution",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = GoZeeTextPrimary
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Petrol Bike
          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB))
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("Petrol Motorcycle", fontSize = 11.sp, color = GoZeeTextMuted)
              Text("55%", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoZeeBlack)
              Text("78 Captains", fontSize = 10.sp, color = GoZeeTextSecondary)
            }
          }

          // Electric Scooter
          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4))
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("EV Scooters", fontSize = 11.sp, color = GoZeeGreen)
              Text("40%", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoZeeGreen)
              Text("57 Captains", fontSize = 10.sp, color = GoZeeTextSecondary)
            }
          }

          // Parcel Scooter
          Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF))
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("Quick Parcel", fontSize = 11.sp, color = Color(0xFF3B82F6))
              Text("5%", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3B82F6))
              Text("7 Captains", fontSize = 10.sp, color = GoZeeTextSecondary)
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}

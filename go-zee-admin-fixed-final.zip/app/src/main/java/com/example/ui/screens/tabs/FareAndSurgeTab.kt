package com.example.ui.screens.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FareConfig
import com.example.ui.theme.GoZeeBlack
import com.example.ui.theme.GoZeeGreen
import com.example.ui.theme.GoZeeSurface
import com.example.ui.theme.GoZeeTextMuted
import com.example.ui.theme.GoZeeTextPrimary
import com.example.ui.theme.GoZeeTextSecondary
import com.example.ui.theme.GoZeeYellow

@Composable
fun FareAndSurgeTab(
  fareConfig: FareConfig,
  onSaveRates: (base: Double, perKm: Double, commission: Int, nightActive: Boolean, helpline: String) -> Unit,
  onUpdateSurge: (Float) -> Unit,
  modifier: Modifier = Modifier
) {
  var baseFareText by remember(fareConfig.baseFare) { mutableStateOf(fareConfig.baseFare.toString()) }
  var perKmText by remember(fareConfig.perKmRate) { mutableStateOf(fareConfig.perKmRate.toString()) }
  var commissionText by remember(fareConfig.commissionPct) { mutableStateOf(fareConfig.commissionPct.toString()) }
  var nightActive by remember(fareConfig.nightChargeActive) { mutableStateOf(fareConfig.nightChargeActive) }
  var helplineText by remember(fareConfig.sosHelpline) { mutableStateOf(fareConfig.sosHelpline) }

  // Interactive Live Estimator
  var estimateDistanceKm by remember { mutableFloatStateOf(6.0f) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 8.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Dynamic Surge Multiplier Card
    Card(
      modifier = Modifier.fillMaxWidth().testTag("surge_slider_card"),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GoZeeSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Bolt, contentDescription = "Surge", tint = GoZeeYellow, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Peak Demand Surge Multiplier",
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
              color = GoZeeTextPrimary
            )
          }

          Box(
            modifier = Modifier
              .background(GoZeeYellow, RoundedCornerShape(6.dp))
              .padding(horizontal = 10.dp, vertical = 4.dp)
          ) {
            Text(
              text = "${String.format("%.1fx", fareConfig.surgeMultiplier)}",
              fontSize = 14.sp,
              fontWeight = FontWeight.Black,
              color = GoZeeBlack
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "Drag to adjust citywide surge pricing dynamically in real time.",
          fontSize = 12.sp,
          color = GoZeeTextSecondary
        )

        Slider(
          value = fareConfig.surgeMultiplier,
          onValueChange = { onUpdateSurge((it * 10).toInt() / 10f) },
          valueRange = 1.0f..2.5f,
          steps = 14,
          colors = SliderDefaults.colors(
            thumbColor = GoZeeBlack,
            activeTrackColor = GoZeeYellow,
            inactiveTrackColor = Color(0xFFE5E7EB)
          ),
          modifier = Modifier.testTag("surge_slider")
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text("1.0x (Standard)", fontSize = 11.sp, color = GoZeeTextMuted)
          Text("1.5x (Rain / Rush)", fontSize = 11.sp, color = GoZeeTextMuted)
          Text("2.5x (Severe Peak)", fontSize = 11.sp, color = GoZeeTextMuted)
        }
      }
    }

    // Base Rates & Commission Card
    Card(
      modifier = Modifier.fillMaxWidth().testTag("base_rates_card"),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GoZeeSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Text(
          text = "Base Fare & Driver Commission",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = GoZeeTextPrimary
        )
        Text(
          text = "Configure pricing matrix for standard two-wheeler bike taxi trips",
          fontSize = 12.sp,
          color = GoZeeTextSecondary,
          modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedTextField(
            value = baseFareText,
            onValueChange = { baseFareText = it },
            label = { Text("Base Fare (₹)") },
            modifier = Modifier.weight(1f).testTag("base_fare_input"),
            singleLine = true
          )

          OutlinedTextField(
            value = perKmText,
            onValueChange = { perKmText = it },
            label = { Text("Per KM Rate (₹)") },
            modifier = Modifier.weight(1f).testTag("per_km_input"),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedTextField(
            value = commissionText,
            onValueChange = { commissionText = it },
            label = { Text("GO ZEE Share (%)") },
            modifier = Modifier.weight(1f).testTag("commission_input"),
            singleLine = true
          )

          OutlinedTextField(
            value = helplineText,
            onValueChange = { helplineText = it },
            label = { Text("SOS Helpline") },
            modifier = Modifier.weight(1f).testTag("sos_helpline_input"),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Night surcharge toggle
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF9FAFB), RoundedCornerShape(8.dp))
            .padding(10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.NightlightRound, contentDescription = "Night", tint = Color(0xFF6366F1), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text("Night Surcharge Mode", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
              Text("Add flat +₹20 between 10:00 PM and 05:00 AM", fontSize = 11.sp, color = GoZeeTextSecondary)
            }
          }
          Switch(
            checked = nightActive,
            onCheckedChange = { nightActive = it },
            colors = SwitchDefaults.colors(
              checkedTrackColor = GoZeeGreen,
              checkedThumbColor = Color.White
            ),
            modifier = Modifier.testTag("night_surcharge_switch")
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Button(
          onClick = {
            val base = baseFareText.toDoubleOrNull() ?: fareConfig.baseFare
            val perKm = perKmText.toDoubleOrNull() ?: fareConfig.perKmRate
            val comm = commissionText.toIntOrNull() ?: fareConfig.commissionPct
            onSaveRates(base, perKm, comm, nightActive, helplineText)
          },
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_fare_rates_button"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(containerColor = GoZeeYellow, contentColor = GoZeeBlack)
        ) {
          Icon(Icons.Default.Save, contentDescription = "Save")
          Spacer(modifier = Modifier.width(6.dp))
          Text("Save Fare Settings", fontWeight = FontWeight.Bold)
        }
      }
    }

    // Live Fare Calculator Sandbox Card
    Card(
      modifier = Modifier.fillMaxWidth().testTag("live_calculator_card"),
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = GoZeeSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Calculate, contentDescription = "Calc", tint = GoZeeBlack, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Trip Fare Estimator Sandbox",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = GoZeeTextPrimary
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "Simulate trip fare for: ${String.format("%.1f", estimateDistanceKm)} km",
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium,
          color = GoZeeTextSecondary
        )

        Slider(
          value = estimateDistanceKm,
          onValueChange = { estimateDistanceKm = (it * 10).toInt() / 10f },
          valueRange = 1.0f..25.0f,
          colors = SliderDefaults.colors(
            thumbColor = GoZeeBlack,
            activeTrackColor = GoZeeGreen
          ),
          modifier = Modifier.testTag("estimate_distance_slider")
        )

        val currentBase = baseFareText.toDoubleOrNull() ?: fareConfig.baseFare
        val currentPerKm = perKmText.toDoubleOrNull() ?: fareConfig.perKmRate
        val currentComm = commissionText.toIntOrNull() ?: fareConfig.commissionPct
        val nightFlat = if (nightActive) 20.0 else 0.0

        val estimatedTotal = ((currentBase + (estimateDistanceKm * currentPerKm) + nightFlat) * fareConfig.surgeMultiplier)
        val platformShare = estimatedTotal * (currentComm / 100.0)
        val captainPayout = estimatedTotal - platformShare

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFF3F4F6))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text("Customer Pays", fontSize = 11.sp, color = GoZeeTextMuted)
            Text("₹${String.format("%.0f", estimatedTotal)}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = GoZeeBlack)
          }

          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Captain Payout (${100 - currentComm}%)", fontSize = 11.sp, color = GoZeeTextMuted)
            Text("₹${String.format("%.0f", captainPayout)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = GoZeeGreen)
          }

          Column(horizontalAlignment = Alignment.End) {
            Text("GO ZEE Share (${currentComm}%)", fontSize = 11.sp, color = GoZeeTextMuted)
            Text("₹${String.format("%.0f", platformShare)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3B82F6))
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}

package com.example.ui.screens.tabs

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Captain
import com.example.model.KycStatus
import com.example.ui.components.CaptainCard
import com.example.ui.theme.GoZeeBlack
import com.example.ui.theme.GoZeeSurface
import com.example.ui.theme.GoZeeTextMuted
import com.example.ui.theme.GoZeeTextPrimary
import com.example.ui.theme.GoZeeYellow

@Composable
fun CaptainsTab(
  captains: List<Captain>,
  searchQuery: String,
  selectedKyc: KycStatus?,
  onSearchChange: (String) -> Unit,
  onKycSelect: (KycStatus?) -> Unit,
  onCaptainClick: (Captain) -> Unit,
  onToggleOnline: (String) -> Unit,
  onApproveKyc: (String) -> Unit,
  onSuspendCaptain: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
  ) {
    // Search Bar
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchChange,
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 4.dp, bottom = 8.dp)
        .testTag("captains_search_input"),
      placeholder = { Text("Search captains, vehicle plate, phone...") },
      leadingIcon = {
        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF6B7280))
      },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { onSearchChange("") }) {
            Icon(Icons.Default.Clear, contentDescription = "Clear search")
          }
        }
      },
      shape = RoundedCornerShape(12.dp),
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White,
        focusedBorderColor = GoZeeYellow,
        unfocusedBorderColor = Color(0xFFE5E7EB)
      )
    )

    // Filter Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 12.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      FilterChip(
        selected = selectedKyc == null,
        onClick = { onKycSelect(null) },
        label = { Text("All", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = GoZeeYellow,
          selectedLabelColor = GoZeeBlack
        ),
        modifier = Modifier.testTag("filter_captain_all")
      )

      FilterChip(
        selected = selectedKyc == KycStatus.VERIFIED,
        onClick = { onKycSelect(if (selectedKyc == KycStatus.VERIFIED) null else KycStatus.VERIFIED) },
        label = { Text("Verified", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = GoZeeYellow,
          selectedLabelColor = GoZeeBlack
        ),
        modifier = Modifier.testTag("filter_captain_verified")
      )

      FilterChip(
        selected = selectedKyc == KycStatus.PENDING,
        onClick = { onKycSelect(if (selectedKyc == KycStatus.PENDING) null else KycStatus.PENDING) },
        label = { Text("Pending KYC", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = GoZeeYellow,
          selectedLabelColor = GoZeeBlack
        ),
        modifier = Modifier.testTag("filter_captain_pending")
      )

      FilterChip(
        selected = selectedKyc == KycStatus.REJECTED,
        onClick = { onKycSelect(if (selectedKyc == KycStatus.REJECTED) null else KycStatus.REJECTED) },
        label = { Text("Suspended", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
        colors = FilterChipDefaults.filterChipColors(
          selectedContainerColor = GoZeeYellow,
          selectedLabelColor = GoZeeBlack
        ),
        modifier = Modifier.testTag("filter_captain_suspended")
      )
    }

    if (captains.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
      ) {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = GoZeeSurface)
        ) {
          Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "No captains found",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = GoZeeTextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Try adjusting your search query or filter tags.",
              fontSize = 12.sp,
              color = GoZeeTextMuted
            )
          }
        }
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize().testTag("captains_list")
      ) {
        items(captains, key = { it.id }) { captain ->
          CaptainCard(
            captain = captain,
            onClick = { onCaptainClick(captain) },
            onToggleOnline = { onToggleOnline(captain.id) },
            onApproveKyc = { onApproveKyc(captain.id) },
            onSuspend = { onSuspendCaptain(captain.id) }
          )
        }
        item {
          Spacer(modifier = Modifier.height(20.dp))
        }
      }
    }
  }
}

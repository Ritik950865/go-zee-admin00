package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = GoZeeYellow,
    onPrimary = GoZeeBlack,
    primaryContainer = GoZeeYellowDark,
    onPrimaryContainer = GoZeeBlack,
    secondary = GoZeeGreen,
    onSecondary = Color.White,
    background = GoZeeBlack,
    surface = GoZeeSurfaceDark,
    onBackground = Color.White,
    onSurface = Color.White,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = GoZeeYellow,
    onPrimary = GoZeeBlack,
    primaryContainer = GoZeeYellowLight,
    onPrimaryContainer = GoZeeBlack,
    secondary = GoZeeGreen,
    onSecondary = Color.White,
    background = GoZeeBackground,
    surface = GoZeeSurface,
    onBackground = GoZeeTextPrimary,
    onSurface = GoZeeTextPrimary,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // For GO ZEE Admin brand consistency, we enforce brand Yellow & Black color scheme
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}


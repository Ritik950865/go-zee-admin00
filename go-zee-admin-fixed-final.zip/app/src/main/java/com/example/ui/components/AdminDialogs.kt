package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBike
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Captain
import com.example.model.RideItem
import com.example.model.RideStatus
import com.example.model.VehicleType
import com.example.ui.theme.GoZeeBlack
import com.example.ui.theme.GoZeeBorder
import com.example.ui.theme.GoZeeGreen
import com.example.ui.theme.GoZeeRed
import com.example.ui.theme.GoZeeTextMuted
import com.example.ui.theme.GoZeeTextPrimary
import com.example.ui.theme.GoZeeTextSecondary
import com.example.ui.theme.GoZeeYellow

@Composable
fun DispatchRideDialog(
  onDismiss: () -> Unit,
  onDispatch: (riderName: String, phone: String, pickup: String, drop: String, type: VehicleType, distance: Double) -> Unit
) {
  var riderName by remember { mutableStateOf("") }
  var phone by remember { mutableStateOf("") }
  var pickup by remember { mutableStateOf("") }
  var drop by remember { mutableStateOf("") }
  var vehicleType by remember { mutableStateOf(VehicleType.BIKE_TAXI) }
  var distanceText by remember { mutableStateOf("5.2") }
  var errorText by remember { mutableStateOf<String?>(null) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      modifier = Modifier.fillMaxWidth().testTag("dispatch_ride_dialog")
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Dispatch Ride / Parcel",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = GoZeeBlack
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (errorText != null) {
          Text(
            text = errorText ?: "",
            color = GoZeeRed,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
          )
        }

        OutlinedTextField(
          value = riderName,
          onValueChange = { riderName = it; errorText = null },
          label = { Text("Customer / Rider Name") },
          modifier = Modifier.fillMaxWidth().testTag("dispatch_rider_name"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it; errorText = null },
          label = { Text("Contact Number") },
          modifier = Modifier.fillMaxWidth().testTag("dispatch_rider_phone"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = pickup,
          onValueChange = { pickup = it; errorText = null },
          label = { Text("Pickup Location") },
          modifier = Modifier.fillMaxWidth().testTag("dispatch_pickup"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = drop,
          onValueChange = { drop = it; errorText = null },
          label = { Text("Destination / Drop Location") },
          modifier = Modifier.fillMaxWidth().testTag("dispatch_drop"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = distanceText,
          onValueChange = { distanceText = it },
          label = { Text("Estimated Distance (km)") },
          modifier = Modifier.fillMaxWidth().testTag("dispatch_distance"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text("Select Vehicle Service:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          VehicleType.values().forEach { type ->
            FilterChip(
              selected = vehicleType == type,
              onClick = { vehicleType = type },
              label = { Text(type.label, fontSize = 11.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = GoZeeYellow,
                selectedLabelColor = GoZeeBlack
              )
            )
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End
        ) {
          OutlinedButton(onClick = onDismiss) {
            Text("Cancel")
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              if (riderName.isBlank() || pickup.isBlank() || drop.isBlank()) {
                errorText = "Please fill in all details"
              } else {
                val dist = distanceText.toDoubleOrNull() ?: 4.5
                onDispatch(riderName, phone.ifBlank { "+91 98000 00000" }, pickup, drop, vehicleType, dist)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoZeeYellow, contentColor = GoZeeBlack),
            modifier = Modifier.testTag("confirm_dispatch_button")
          ) {
            Text("Dispatch Now", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun BroadcastDialog(
  onDismiss: () -> Unit,
  onSend: (title: String, message: String, isUrgent: Boolean) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var message by remember { mutableStateOf("") }
  var isUrgent by remember { mutableStateOf(false) }
  var errorText by remember { mutableStateOf<String?>(null) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      modifier = Modifier.fillMaxWidth().testTag("broadcast_dialog")
    ) {
      Column(
        modifier = Modifier.padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Campaign, contentDescription = "Broadcast", tint = GoZeeYellow, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Broadcast Alert",
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = GoZeeBlack
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close")
          }
        }

        Text(
          text = "Send real-time announcement to all 140+ on-duty captains",
          fontSize = 12.sp,
          color = GoZeeTextSecondary,
          modifier = Modifier.padding(bottom = 12.dp)
        )

        if (errorText != null) {
          Text(errorText ?: "", color = GoZeeRed, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
        }

        OutlinedTextField(
          value = title,
          onValueChange = { title = it; errorText = null },
          label = { Text("Announcement Title") },
          modifier = Modifier.fillMaxWidth().testTag("broadcast_title"),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = message,
          onValueChange = { message = it; errorText = null },
          label = { Text("Message details...") },
          modifier = Modifier.fillMaxWidth().height(100.dp).testTag("broadcast_message"),
          maxLines = 4
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Checkbox(
            checked = isUrgent,
            onCheckedChange = { isUrgent = it },
            colors = CheckboxDefaults.colors(checkedColor = GoZeeRed)
          )
          Text("Mark as High Priority Alert (Vibrate & Sound)", fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End
        ) {
          OutlinedButton(onClick = onDismiss) {
            Text("Cancel")
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = {
              if (title.isBlank() || message.isBlank()) {
                errorText = "Please enter title and message"
              } else {
                onSend(title, message, isUrgent)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoZeeYellow, contentColor = GoZeeBlack),
            modifier = Modifier.testTag("send_broadcast_button")
          ) {
            Text("Send Broadcast", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun RideDetailDialog(
  ride: RideItem,
  onDismiss: () -> Unit,
  onComplete: () -> Unit,
  onCancel: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      modifier = Modifier.fillMaxWidth().testTag("ride_detail_dialog")
    ) {
      Column(
        modifier = Modifier
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(ride.id, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = GoZeeBlack)
            Text("${ride.vehicleType.label} • ${ride.timeAgo}", fontSize = 12.sp, color = GoZeeTextSecondary)
          }
          StatusBadge(status = ride.status)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Route details
        Text("ROUTE BREAKDOWN", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GoZeeTextMuted)
        Spacer(modifier = Modifier.height(8.dp))
        Row {
          Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 4.dp, end = 10.dp)) {
            Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(GoZeeGreen))
            Box(modifier = Modifier.width(2.dp).height(36.dp).background(GoZeeBorder))
            Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(GoZeeRed))
          }
          Column {
            Text("Pickup Point", fontSize = 10.sp, color = GoZeeTextMuted)
            Text(ride.pickupAddress, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(14.dp))
            Text("Drop Point", fontSize = 10.sp, color = GoZeeTextMuted)
            Text(ride.dropAddress, fontSize = 13.sp, fontWeight = FontWeight.Medium)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Participants
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Column(modifier = Modifier.weight(1f)) {
            Text("RIDER DETAILS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoZeeTextMuted)
            Text(ride.riderName, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(ride.riderPhone, fontSize = 12.sp, color = GoZeeTextSecondary)
          }
          Column(modifier = Modifier.weight(1f)) {
            Text("CAPTAIN DETAILS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GoZeeTextMuted)
            Text(ride.captainName, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(ride.captainPhone, fontSize = 12.sp, color = GoZeeTextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Financials
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF9FAFB), RoundedCornerShape(8.dp))
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("Payment Method", fontSize = 11.sp, color = GoZeeTextMuted)
            Text(ride.paymentMethod.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
          }
          Column(horizontalAlignment = Alignment.End) {
            Text("Total Fare", fontSize = 11.sp, color = GoZeeTextMuted)
            Text("₹${String.format("%.2f", ride.fare)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoZeeBlack)
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End
        ) {
          OutlinedButton(onClick = onDismiss) {
            Text("Close")
          }
          if (ride.status == RideStatus.ONGOING) {
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(onClick = onCancel) {
              Text("Cancel Ride", color = GoZeeRed)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
              onClick = onComplete,
              colors = ButtonDefaults.buttonColors(containerColor = GoZeeGreen)
            ) {
              Text("Complete Trip")
            }
          }
        }
      }
    }
  }
}

@Composable
fun LogoutConfirmDialog(
  onDismiss: () -> Unit,
  onConfirm: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Logout of Admin Panel?") },
    text = { Text("You will be returned to the GO ZEE Admin login screen.") },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(containerColor = GoZeeRed),
        modifier = Modifier.testTag("confirm_logout_button")
      ) {
        Text("Logout", color = Color.White)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("Stay")
      }
    },
    modifier = Modifier.testTag("logout_confirm_dialog")
  )
}

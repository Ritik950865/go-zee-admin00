package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoZeeBlack
import com.example.ui.theme.GoZeeYellow
import com.example.ui.theme.GoZeeYellowDark

@Composable
fun AdminLoginScreen(
  onLoginSuccess: (email: String, pass: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var email by remember { mutableStateOf("admin@gozee.bike") }
  var password by remember { mutableStateOf("admin123") }
  var passwordVisible by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val focusManager = LocalFocusManager.current

  Surface(
    modifier = modifier.fillMaxSize(),
    color = GoZeeBlack
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .imePadding()
    ) {
      // Top Half: Yellow Container matching Flutter layout
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .background(GoZeeYellow),
        contentAlignment = Alignment.Center
      ) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center,
          modifier = Modifier.padding(16.dp)
        ) {
          Text(
            text = "GO ZEE",
            style = androidx.compose.ui.text.TextStyle(
              fontFamily = FontFamily.Default,
              fontSize = 52.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.5.sp,
              color = GoZeeBlack
            ),
            textAlign = TextAlign.Center
          )
          Text(
            text = "Admin Panel",
            style = androidx.compose.ui.text.TextStyle(
              fontFamily = FontFamily.Default,
              fontSize = 22.sp,
              fontWeight = FontWeight.Bold,
              color = GoZeeBlack
            ),
            textAlign = TextAlign.Center
          )
          Spacer(modifier = Modifier.height(25.dp))
          Icon(
            imageVector = Icons.Filled.TwoWheeler,
            contentDescription = "Two Wheeler Motorcycle Icon",
            modifier = Modifier
              .size(100.dp)
              .testTag("login_bike_icon"),
            tint = GoZeeBlack
          )
        }
      }

      // Bottom Half: White Container matching Flutter layout
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1.15f)
          .background(Color.White)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 20.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Text(
            text = "Welcome Back",
            style = androidx.compose.ui.text.TextStyle(
              fontFamily = FontFamily.Default,
              fontSize = 27.sp,
              fontWeight = FontWeight.Bold,
              color = GoZeeBlack
            )
          )

          Text(
            text = "Fleet & Operations Command Center",
            fontSize = 13.sp,
            color = Color(0xFF6B7280),
            modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
          )

          if (errorMessage != null) {
            Text(
              text = errorMessage ?: "",
              color = Color(0xFFDC2626),
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium,
              modifier = Modifier
                .padding(bottom = 8.dp)
                .testTag("error_message_text")
            )
          }

          // Email / Mobile Number Field
          OutlinedTextField(
            value = email,
            onValueChange = {
              email = it
              errorMessage = null
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("email_input"),
            placeholder = { Text("Email / Mobile Number") },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Email,
                contentDescription = "Email Icon",
                tint = Color(0xFF6B7280)
              )
            },
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            keyboardOptions = KeyboardOptions(
              keyboardType = KeyboardType.Email,
              imeAction = ImeAction.Next
            ),
            keyboardActions = KeyboardActions(
              onNext = { focusManager.moveFocus(FocusDirection.Down) }
            ),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = GoZeeYellowDark,
              unfocusedBorderColor = Color(0xFFD1D5DB),
              focusedTextColor = GoZeeBlack,
              unfocusedTextColor = GoZeeBlack,
              focusedContainerColor = Color(0xFFFAFAFA),
              unfocusedContainerColor = Color(0xFFFAFAFA)
            )
          )

          Spacer(modifier = Modifier.height(12.dp))

          // Password Field
          OutlinedTextField(
            value = password,
            onValueChange = {
              password = it
              errorMessage = null
            },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("password_input"),
            placeholder = { Text("Password") },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Password Icon",
                tint = Color(0xFF6B7280)
              )
            },
            trailingIcon = {
              IconButton(
                onClick = { passwordVisible = !passwordVisible },
                modifier = Modifier.testTag("toggle_password_visibility")
              ) {
                Icon(
                  imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                  contentDescription = if (passwordVisible) "Hide password" else "Show password",
                  tint = Color(0xFF6B7280)
                )
              }
            },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            keyboardOptions = KeyboardOptions(
              keyboardType = KeyboardType.Password,
              imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
              onDone = {
                focusManager.clearFocus()
                if (email.isBlank() || password.isBlank()) {
                  errorMessage = "Please enter valid credentials"
                } else {
                  onLoginSuccess(email, password)
                }
              }
            ),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = GoZeeYellowDark,
              unfocusedBorderColor = Color(0xFFD1D5DB),
              focusedTextColor = GoZeeBlack,
              unfocusedTextColor = GoZeeBlack,
              focusedContainerColor = Color(0xFFFAFAFA),
              unfocusedContainerColor = Color(0xFFFAFAFA)
            )
          )

          Spacer(modifier = Modifier.height(18.dp))

          // Login Button: Exactly matching style from Flutter code
          Button(
            onClick = {
              focusManager.clearFocus()
              if (email.isBlank() || password.isBlank()) {
                errorMessage = "Please enter email and password"
              } else {
                onLoginSuccess(email, password)
              }
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("login_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = GoZeeYellow,
              contentColor = GoZeeBlack
            ),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
          ) {
            Text(
              text = "LOGIN",
              style = androidx.compose.ui.text.TextStyle(
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = GoZeeBlack
              )
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Quick Demo Credentials Fill for instant review
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedButton(
              onClick = {
                email = "admin@gozee.bike"
                password = "admin"
                errorMessage = null
              },
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.testTag("demo_credentials_button")
            ) {
              Text(
                text = "⚡ Fill Demo Credentials",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = GoZeeBlack
              )
            }
          }
        }
      }
    }
  }
}

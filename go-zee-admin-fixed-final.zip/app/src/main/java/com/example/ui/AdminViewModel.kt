package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AdminRepository
import com.example.model.BroadcastAlert
import com.example.model.Captain
import com.example.model.DashboardMetrics
import com.example.model.FareConfig
import com.example.model.KycStatus
import com.example.model.RideItem
import com.example.model.RideStatus
import com.example.model.VehicleType
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AdminTab(val title: String) {
  OVERVIEW("Overview"),
  RIDES("Rides"),
  CAPTAINS("Captains"),
  FARES("Fare & Surge"),
  ANALYTICS("Analytics")
}

class AdminViewModel(
  private val repository: AdminRepository = AdminRepository()
) : ViewModel() {

  val isLoggedIn: StateFlow<Boolean> = repository.isLoggedIn
  val adminEmail: StateFlow<String> = repository.adminEmail
  val metrics: StateFlow<DashboardMetrics> = repository.metrics
  val fareConfig: StateFlow<FareConfig> = repository.fareConfig
  val alerts: StateFlow<List<BroadcastAlert>> = repository.alerts

  // Navigation
  private val _selectedTab = MutableStateFlow(AdminTab.OVERVIEW)
  val selectedTab: StateFlow<AdminTab> = _selectedTab.asStateFlow()

  // Search
  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  // Filter selections
  private val _selectedRideFilter = MutableStateFlow<RideStatus?>(null)
  val selectedRideFilter: StateFlow<RideStatus?> = _selectedRideFilter.asStateFlow()

  private val _selectedKycFilter = MutableStateFlow<KycStatus?>(null)
  val selectedKycFilter: StateFlow<KycStatus?> = _selectedKycFilter.asStateFlow()

  // Filtered Rides
  val filteredRides: StateFlow<List<RideItem>> = combine(
    repository.rides,
    _selectedRideFilter,
    _searchQuery
  ) { rides, filter, query ->
    rides.filter { ride ->
      val matchesFilter = filter == null || ride.status == filter
      val matchesQuery = query.isBlank() ||
          ride.id.contains(query, ignoreCase = true) ||
          ride.riderName.contains(query, ignoreCase = true) ||
          ride.captainName.contains(query, ignoreCase = true) ||
          ride.pickupAddress.contains(query, ignoreCase = true) ||
          ride.dropAddress.contains(query, ignoreCase = true)
      matchesFilter && matchesQuery
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Filtered Captains
  val filteredCaptains: StateFlow<List<Captain>> = combine(
    repository.captains,
    _selectedKycFilter,
    _searchQuery
  ) { captains, filter, query ->
    captains.filter { captain ->
      val matchesFilter = filter == null || captain.kycStatus == filter
      val matchesQuery = query.isBlank() ||
          captain.name.contains(query, ignoreCase = true) ||
          captain.phone.contains(query, ignoreCase = true) ||
          captain.bikeModel.contains(query, ignoreCase = true) ||
          captain.registrationNumber.contains(query, ignoreCase = true)
      matchesFilter && matchesQuery
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // UI Dialog states
  private val _selectedRideForDetail = MutableStateFlow<RideItem?>(null)
  val selectedRideForDetail: StateFlow<RideItem?> = _selectedRideForDetail.asStateFlow()

  private val _selectedCaptainForDetail = MutableStateFlow<Captain?>(null)
  val selectedCaptainForDetail: StateFlow<Captain?> = _selectedCaptainForDetail.asStateFlow()

  private val _showBroadcastDialog = MutableStateFlow(false)
  val showBroadcastDialog: StateFlow<Boolean> = _showBroadcastDialog.asStateFlow()

  private val _showDispatchDialog = MutableStateFlow(false)
  val showDispatchDialog: StateFlow<Boolean> = _showDispatchDialog.asStateFlow()

  private val _showLogoutConfirmDialog = MutableStateFlow(false)
  val showLogoutConfirmDialog: StateFlow<Boolean> = _showLogoutConfirmDialog.asStateFlow()

  private val _snackbarMessage = MutableStateFlow<String?>(null)
  val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

  // Actions
  fun onSelectTab(tab: AdminTab) {
    _selectedTab.value = tab
  }

  fun onSearchQueryChange(query: String) {
    _searchQuery.value = query
  }

  fun onRideFilterChange(filter: RideStatus?) {
    _selectedRideFilter.value = filter
  }

  fun onKycFilterChange(filter: KycStatus?) {
    _selectedKycFilter.value = filter
  }

  fun login(email: String, pass: String, onSuccess: () -> Unit = {}, onError: (String) -> Unit = {}) {
    viewModelScope.launch {
      if (email.isBlank() || pass.isBlank()) {
        onError("Please enter both email/mobile and password.")
        return@launch
      }
      val ok = repository.login(email, pass)
      if (ok) {
        _snackbarMessage.value = "Welcome back, Admin!"
        onSuccess()
      } else {
        onError("Invalid admin credentials.")
      }
    }
  }

  fun logout() {
    repository.logout()
    _selectedTab.value = AdminTab.OVERVIEW
    _showLogoutConfirmDialog.value = false
    _snackbarMessage.value = "Logged out successfully"
  }

  fun updateSurge(multiplier: Float) {
    repository.updateSurgeMultiplier(multiplier)
    _snackbarMessage.value = "Surge updated to ${String.format("%.1fx", multiplier)}"
  }

  fun updateRates(base: Double, perKm: Double, commission: Int, nightActive: Boolean, helpline: String) {
    repository.updateFareRates(base, perKm, commission, nightActive, helpline)
    _snackbarMessage.value = "Fare settings saved successfully!"
  }

  fun approveCaptain(captainId: String) {
    repository.verifyCaptain(captainId)
    _snackbarMessage.value = "Captain $captainId approved for duty!"
    _selectedCaptainForDetail.value = null
  }

  fun suspendCaptain(captainId: String) {
    repository.suspendCaptain(captainId)
    _snackbarMessage.value = "Captain $captainId has been suspended."
    _selectedCaptainForDetail.value = null
  }

  fun toggleCaptainOnline(captainId: String) {
    repository.toggleCaptainOnline(captainId)
  }

  fun cancelRide(rideId: String) {
    repository.cancelRide(rideId)
    _snackbarMessage.value = "Ride $rideId cancelled."
    _selectedRideForDetail.value = null
  }

  fun completeRide(rideId: String) {
    repository.completeRide(rideId)
    _snackbarMessage.value = "Ride $rideId marked completed."
    _selectedRideForDetail.value = null
  }

  fun dispatchRide(
    riderName: String,
    riderPhone: String,
    pickup: String,
    drop: String,
    type: VehicleType,
    distanceKm: Double
  ) {
    repository.dispatchNewRide(riderName, riderPhone, pickup, drop, type, distanceKm)
    _showDispatchDialog.value = false
    _snackbarMessage.value = "New ride dispatched to nearest Captain!"
  }

  fun sendBroadcast(title: String, message: String, isUrgent: Boolean) {
    repository.addBroadcast(title, message, isUrgent)
    _showBroadcastDialog.value = false
    _snackbarMessage.value = "Broadcast sent to all active captains!"
  }

  fun showRideDetail(ride: RideItem?) {
    _selectedRideForDetail.value = ride
  }

  fun showCaptainDetail(captain: Captain?) {
    _selectedCaptainForDetail.value = captain
  }

  fun setBroadcastDialogVisible(visible: Boolean) {
    _showBroadcastDialog.value = visible
  }

  fun setDispatchDialogVisible(visible: Boolean) {
    _showDispatchDialog.value = visible
  }

  fun setLogoutConfirmVisible(visible: Boolean) {
    _showLogoutConfirmDialog.value = visible
  }

  fun clearSnackbar() {
    _snackbarMessage.value = null
  }
}

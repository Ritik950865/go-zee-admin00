package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBike
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Captain
import com.example.model.KycStatus
import com.example.model.RideItem
import com.example.model.RideStatus
import com.example.model.VehicleType
import com.example.ui.theme.GoZeeBlack
import com.example.ui.theme.GoZeeBorder
import com.example.ui.theme.GoZeeGreen
import com.example.ui.theme.GoZeeGreenLight
import com.example.ui.theme.GoZeeRed
import com.example.ui.theme.GoZeeRedLight
import com.example.ui.theme.GoZeeSurface
import com.example.ui.theme.GoZeeTextMuted
import com.example.ui.theme.GoZeeTextPrimary
import com.example.ui.theme.GoZeeTextSecondary
import com.example.ui.theme.GoZeeYellow

@Composable
fun MetricStatCard(
  title: String,
  value: String,
  subtitle: String,
  icon: ImageVector,
  accentColor: Color,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier.testTag("stat_card_${title.lowercase().replace(" ", "_")}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = GoZeeSurface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier.padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(accentColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = title,
            tint = accentColor,
            modifier = Modifier.size(20.dp)
          )
        }
        Text(
          text = subtitle,
          fontSize = 11.sp,
          fontWeight = FontWeight.SemiBold,
          color = if (subtitle.startsWith("+")) GoZeeGreen else GoZeeTextSecondary
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = value,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = GoZeeTextPrimary
      )

      Text(
        text = title,
        fontSize = 12.sp,
        color = GoZeeTextSecondary,
        fontWeight = FontWeight.Medium
      )
    }
  }
}

@Composable
fun RideCard(
  ride: RideItem,
  onClick: () -> Unit,
  onComplete: () -> Unit,
  onCancel: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("ride_card_${ride.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      // Header: Ride ID, Vehicle badge, Status chip
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = when (ride.vehicleType) {
              VehicleType.BIKE_TAXI -> Icons.Filled.TwoWheeler
              VehicleType.EV_SCOOTER -> Icons.Filled.ElectricBike
              VehicleType.QUICK_DELIVERY -> Icons.Filled.LocalShipping
            },
            contentDescription = ride.vehicleType.label,
            tint = GoZeeBlack,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = ride.id,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = GoZeeTextPrimary
          )
          Text(
            text = " • ${ride.vehicleType.label}",
            fontSize = 12.sp,
            color = GoZeeTextSecondary
          )
        }

        StatusBadge(status = ride.status)
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Locations (Pickup -> Drop)
      Row(modifier = Modifier.fillMaxWidth()) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.padding(top = 4.dp, end = 10.dp)
        ) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(GoZeeGreen)
          )
          Box(
            modifier = Modifier
              .width(2.dp)
              .height(24.dp)
              .background(GoZeeBorder)
          )
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(GoZeeRed)
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = ride.pickupAddress,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = GoZeeTextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = ride.dropAddress,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = GoZeeTextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Footer: Rider & Captain info, Fare, Time
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFFF9FAFB), RoundedCornerShape(8.dp))
          .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Rider: ${ride.riderName}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = GoZeeTextPrimary
          )
          Text(
            text = "Cap: ${ride.captainName}",
            fontSize = 11.sp,
            color = GoZeeTextSecondary
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "₹${String.format("%.0f", ride.fare)}",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = GoZeeBlack
          )
          Text(
            text = "${ride.distanceKm} km • ${ride.paymentMethod.label}",
            fontSize = 10.sp,
            color = GoZeeTextSecondary
          )
        }
      }

      // Action row for ongoing rides
      if (ride.status == RideStatus.ONGOING) {
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedButton(
            onClick = onCancel,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.testTag("cancel_ride_${ride.id}")
          ) {
            Text("Cancel", fontSize = 11.sp, color = GoZeeRed)
          }
          Spacer(modifier = Modifier.width(8.dp))
          Button(
            onClick = onComplete,
            colors = ButtonDefaults.buttonColors(containerColor = GoZeeGreen),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.testTag("complete_ride_${ride.id}")
          ) {
            Text("Complete", fontSize = 11.sp, color = Color.White)
          }
        }
      }
    }
  }
}

@Composable
fun StatusBadge(status: RideStatus) {
  val (bgColor, textColor) = when (status) {
    RideStatus.ONGOING -> Pair(Color(0xFFFEF3C7), Color(0xFFB45309))
    RideStatus.COMPLETED -> Pair(GoZeeGreenLight, Color(0xFF15803D))
    RideStatus.CANCELLED -> Pair(GoZeeRedLight, Color(0xFFB91C1C))
    RideStatus.SEARCHING -> Pair(Color(0xFFE0E7FF), Color(0xFF4338CA))
  }

  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(bgColor)
      .padding(horizontal = 8.dp, vertical = 4.dp)
  ) {
    Text(
      text = status.label,
      fontSize = 11.sp,
      fontWeight = FontWeight.Bold,
      color = textColor
    )
  }
}

@Composable
fun CaptainCard(
  captain: Captain,
  onClick: () -> Unit,
  onToggleOnline: () -> Unit,
  onApproveKyc: () -> Unit,
  onSuspend: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("captain_card_${captain.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(42.dp)
              .clip(CircleShape)
              .background(GoZeeYellow),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = captain.name.take(1),
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = GoZeeBlack
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = captain.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = GoZeeTextPrimary
              )
              Spacer(modifier = Modifier.width(6.dp))
              // Star Rating
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(Color(0xFFFEF3C7))
                  .padding(horizontal = 4.dp, vertical = 2.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Star,
                  contentDescription = "Rating",
                  tint = Color(0xFFF59E0B),
                  modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                  text = captain.rating.toString(),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFFB45309)
                )
              }
            }
            Text(
              text = "${captain.bikeModel} • ${captain.registrationNumber}",
              fontSize = 12.sp,
              color = GoZeeTextSecondary
            )
          }
        }

        // Online Switch
        Column(horizontalAlignment = Alignment.End) {
          Switch(
            checked = captain.isOnline,
            onCheckedChange = { onToggleOnline() },
            colors = SwitchDefaults.colors(
              checkedThumbColor = Color.White,
              checkedTrackColor = GoZeeGreen,
              uncheckedThumbColor = Color.White,
              uncheckedTrackColor = Color(0xFFD1D5DB)
            ),
            modifier = Modifier.testTag("captain_online_switch_${captain.id}")
          )
          Text(
            text = if (captain.isOnline) "ONLINE" else "OFFLINE",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (captain.isOnline) GoZeeGreen else GoZeeTextMuted
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Captain Stats row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
          .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("Phone", fontSize = 10.sp, color = GoZeeTextMuted)
          Text(captain.phone, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Lifetime Trips", fontSize = 10.sp, color = GoZeeTextMuted)
          Text("${captain.totalRides}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Column(horizontalAlignment = Alignment.End) {
          Text("Today's Pay", fontSize = 10.sp, color = GoZeeTextMuted)
          Text("₹${captain.earningsToday.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoZeeGreen)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // KYC & Actions
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Status chip
        val (kycBg, kycText) = when (captain.kycStatus) {
          KycStatus.VERIFIED -> Pair(GoZeeGreenLight, Color(0xFF15803D))
          KycStatus.PENDING -> Pair(Color(0xFFFEF3C7), Color(0xFFB45309))
          KycStatus.REJECTED -> Pair(GoZeeRedLight, Color(0xFFB91C1C))
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(kycBg)
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = captain.kycStatus.label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = kycText
          )
        }

        Row {
          if (captain.kycStatus == KycStatus.PENDING) {
            Button(
              onClick = onApproveKyc,
              colors = ButtonDefaults.buttonColors(containerColor = GoZeeGreen),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.testTag("approve_captain_${captain.id}")
            ) {
              Text("Approve KYC", fontSize = 11.sp, color = Color.White)
            }
          } else if (captain.kycStatus == KycStatus.VERIFIED) {
            OutlinedButton(
              onClick = onSuspend,
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.testTag("suspend_captain_${captain.id}")
            ) {
              Text("Suspend", fontSize = 11.sp, color = GoZeeRed)
            }
          } else {
            Button(
              onClick = onApproveKyc,
              colors = ButtonDefaults.buttonColors(containerColor = GoZeeYellow),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.testTag("reactivate_captain_${captain.id}")
            ) {
              Text("Reactivate", fontSize = 11.sp, color = GoZeeBlack)
            }
          }
        }
      }
    }
  }
}

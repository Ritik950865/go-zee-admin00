package com.example.data

import com.example.model.BroadcastAlert
import com.example.model.Captain
import com.example.model.DashboardMetrics
import com.example.model.FareConfig
import com.example.model.KycStatus
import com.example.model.PaymentMethod
import com.example.model.RideItem
import com.example.model.RideStatus
import com.example.model.VehicleType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class AdminRepository {

  private val _isLoggedIn = MutableStateFlow(false)
  val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

  private val _adminEmail = MutableStateFlow("admin@gozee.bike")
  val adminEmail: StateFlow<String> = _adminEmail.asStateFlow()

  private val _metrics = MutableStateFlow(DashboardMetrics())
  val metrics: StateFlow<DashboardMetrics> = _metrics.asStateFlow()

  private val _fareConfig = MutableStateFlow(FareConfig())
  val fareConfig: StateFlow<FareConfig> = _fareConfig.asStateFlow()

  private val _rides = MutableStateFlow(initialRides())
  val rides: StateFlow<List<RideItem>> = _rides.asStateFlow()

  private val _captains = MutableStateFlow(initialCaptains())
  val captains: StateFlow<List<Captain>> = _captains.asStateFlow()

  private val _alerts = MutableStateFlow(initialAlerts())
  val alerts: StateFlow<List<BroadcastAlert>> = _alerts.asStateFlow()

  fun login(email: String, pass: String): Boolean {
    // Allows admin login
    if (email.isNotBlank() && pass.isNotBlank()) {
      _adminEmail.value = email.trim()
      _isLoggedIn.value = true
      return true
    }
    return false
  }

  fun logout() {
    _isLoggedIn.value = false
  }

  fun updateSurgeMultiplier(multiplier: Float) {
    _fareConfig.update { it.copy(surgeMultiplier = multiplier) }
  }

  fun updateFareRates(base: Double, perKm: Double, commission: Int, nightCharge: Boolean, helpline: String) {
    _fareConfig.update {
      it.copy(
        baseFare = base,
        perKmRate = perKm,
        commissionPct = commission,
        nightChargeActive = nightCharge,
        sosHelpline = helpline
      )
    }
  }

  fun verifyCaptain(captainId: String) {
    _captains.update { list ->
      list.map { captain ->
        if (captain.id == captainId) {
          captain.copy(kycStatus = KycStatus.VERIFIED)
        } else {
          captain
        }
      }
    }
  }

  fun suspendCaptain(captainId: String) {
    _captains.update { list ->
      list.map { captain ->
        if (captain.id == captainId) {
          captain.copy(kycStatus = KycStatus.REJECTED, isOnline = false)
        } else {
          captain
        }
      }
    }
  }

  fun toggleCaptainOnline(captainId: String) {
    _captains.update { list ->
      list.map { captain ->
        if (captain.id == captainId) {
          captain.copy(isOnline = !captain.isOnline)
        } else {
          captain
        }
      }
    }
    recalculateMetrics()
  }

  fun cancelRide(rideId: String) {
    _rides.update { list ->
      list.map { ride ->
        if (ride.id == rideId) {
          ride.copy(status = RideStatus.CANCELLED)
        } else {
          ride
        }
      }
    }
    recalculateMetrics()
  }

  fun completeRide(rideId: String) {
    _rides.update { list ->
      list.map { ride ->
        if (ride.id == rideId) {
          ride.copy(status = RideStatus.COMPLETED)
        } else {
          ride
        }
      }
    }
    recalculateMetrics()
  }

  fun dispatchNewRide(
    riderName: String,
    riderPhone: String,
    pickup: String,
    drop: String,
    vehicleType: VehicleType,
    distanceKm: Double
  ) {
    val surge = _fareConfig.value.surgeMultiplier
    val calculatedFare = ((_fareConfig.value.baseFare + (distanceKm * _fareConfig.value.perKmRate)) * surge).coerceAtLeast(30.0)
    val availableCaptain = _captains.value.firstOrNull { it.isOnline && it.kycStatus == KycStatus.VERIFIED }
    val captainName = availableCaptain?.name ?: "Assigning Nearby Captain..."
    val captainPhone = availableCaptain?.phone ?: "+91 98765 00000"

    val newRide = RideItem(
      id = "GZ-${(1000..9999).random()}",
      riderName = riderName,
      riderPhone = riderPhone,
      captainName = captainName,
      captainPhone = captainPhone,
      pickupAddress = pickup,
      dropAddress = drop,
      fare = (calculatedFare * 10).toInt() / 10.0,
      status = RideStatus.ONGOING,
      vehicleType = vehicleType,
      distanceKm = distanceKm,
      timeAgo = "Just now",
      paymentMethod = PaymentMethod.UPI
    )

    _rides.update { listOf(newRide) + it }
    recalculateMetrics()
  }

  fun addBroadcast(title: String, message: String, isUrgent: Boolean) {
    val newAlert = BroadcastAlert(
      id = "ALT-${System.currentTimeMillis() % 10000}",
      title = title,
      message = message,
      time = "Just now",
      isUrgent = isUrgent
    )
    _alerts.update { listOf(newAlert) + it }
  }

  private fun recalculateMetrics() {
    val currentRides = _rides.value
    val activeCount = currentRides.count { it.status == RideStatus.ONGOING }
    val completedCount = currentRides.count { it.status == RideStatus.COMPLETED }
    val onlineCaptains = _captains.value.count { it.isOnline && it.kycStatus == KycStatus.VERIFIED }
    val totalRev = currentRides.filter { it.status == RideStatus.COMPLETED }.sumOf { it.fare } + 42000.0

    _metrics.update {
      it.copy(
        activeBookings = activeCount,
        totalTripsToday = 1250 + completedCount,
        activeCaptains = onlineCaptains * 18, // scaled for city fleet representation
        totalRevenue = totalRev
      )
    }
  }

  companion object {
    private fun initialRides(): List<RideItem> = listOf(
      RideItem(
        id = "GZ-8492",
        riderName = "Arjun Mehra",
        riderPhone = "+91 98201 44521",
        captainName = "Ramesh Kumar (Cap-104)",
        captainPhone = "+91 98111 23412",
        pickupAddress = "Central Railway Station, Gate 2",
        dropAddress = "Cyber Tech Park, Tower B",
        fare = 145.0,
        status = RideStatus.ONGOING,
        vehicleType = VehicleType.BIKE_TAXI,
        distanceKm = 8.4,
        timeAgo = "3 mins ago",
        paymentMethod = PaymentMethod.UPI
      ),
      RideItem(
        id = "GZ-8491",
        riderName = "Sneha Kulkarni",
        riderPhone = "+91 98332 99120",
        captainName = "Vikas Sharma (Cap-212)",
        captainPhone = "+91 97654 32190",
        pickupAddress = "Green Glen Layout, Bellandur",
        dropAddress = "Indiranagar 100ft Road",
        fare = 185.0,
        status = RideStatus.ONGOING,
        vehicleType = VehicleType.EV_SCOOTER,
        distanceKm = 11.2,
        timeAgo = "8 mins ago",
        paymentMethod = PaymentMethod.GO_ZEE_WALLET
      ),
      RideItem(
        id = "GZ-8490",
        riderName = "Dr. Farhan Siddiqui",
        riderPhone = "+91 99100 81234",
        captainName = "Manish Yadav (Cap-089)",
        captainPhone = "+91 98234 11223",
        pickupAddress = "Apollo Hospital, Bannerghatta",
        dropAddress = "Jayanagar 4th Block",
        fare = 92.0,
        status = RideStatus.ONGOING,
        vehicleType = VehicleType.BIKE_TAXI,
        distanceKm = 4.8,
        timeAgo = "12 mins ago",
        paymentMethod = PaymentMethod.CASH
      ),
      RideItem(
        id = "GZ-8488",
        riderName = "Pooja Verma",
        riderPhone = "+91 98450 11982",
        captainName = "Ganesh Patil (Cap-340)",
        captainPhone = "+91 91234 56789",
        pickupAddress = "Koramangala Sony World Signal",
        dropAddress = "HSR Sector 2, 27th Main",
        fare = 78.0,
        status = RideStatus.COMPLETED,
        vehicleType = VehicleType.BIKE_TAXI,
        distanceKm = 3.6,
        timeAgo = "24 mins ago",
        paymentMethod = PaymentMethod.UPI
      ),
      RideItem(
        id = "GZ-8487",
        riderName = "MedPlus Pharmacy",
        riderPhone = "+91 98440 22311",
        captainName = "Deepak S (Cap-178)",
        captainPhone = "+91 93456 78120",
        pickupAddress = "MG Road Medical Store Hub",
        dropAddress = "Richmond Town Residence #42",
        fare = 65.0,
        status = RideStatus.COMPLETED,
        vehicleType = VehicleType.QUICK_DELIVERY,
        distanceKm = 2.9,
        timeAgo = "40 mins ago",
        paymentMethod = PaymentMethod.UPI
      ),
      RideItem(
        id = "GZ-8485",
        riderName = "Kunal Rawat",
        riderPhone = "+91 99887 66554",
        captainName = "Sunil Gowda (Cap-052)",
        captainPhone = "+91 98765 43210",
        pickupAddress = "Electronic City Phase 1 Toll",
        dropAddress = "Silk Board Flyover Ramp",
        fare = 110.0,
        status = RideStatus.CANCELLED,
        vehicleType = VehicleType.BIKE_TAXI,
        distanceKm = 7.1,
        timeAgo = "1 hr ago",
        paymentMethod = PaymentMethod.CASH
      )
    )

    private fun initialCaptains(): List<Captain> = listOf(
      Captain(
        id = "CAP-104",
        name = "Ramesh Kumar",
        phone = "+91 98111 23412",
        bikeModel = "Bajaj Pulsar 150",
        registrationNumber = "KA 01 EK 4920",
        rating = 4.9,
        totalRides = 1420,
        earningsToday = 1840.0,
        kycStatus = KycStatus.VERIFIED,
        isOnline = true,
        vehicleType = VehicleType.BIKE_TAXI
      ),
      Captain(
        id = "CAP-212",
        name = "Vikas Sharma",
        phone = "+91 97654 32190",
        bikeModel = "Ather 450X (EV)",
        registrationNumber = "KA 05 MN 8821",
        rating = 4.8,
        totalRides = 980,
        earningsToday = 1450.0,
        kycStatus = KycStatus.VERIFIED,
        isOnline = true,
        vehicleType = VehicleType.EV_SCOOTER
      ),
      Captain(
        id = "CAP-089",
        name = "Manish Yadav",
        phone = "+91 98234 11223",
        bikeModel = "Honda Activa 6G",
        registrationNumber = "KA 03 GH 1204",
        rating = 4.7,
        totalRides = 2100,
        earningsToday = 2100.0,
        kycStatus = KycStatus.VERIFIED,
        isOnline = true,
        vehicleType = VehicleType.BIKE_TAXI
      ),
      Captain(
        id = "CAP-405",
        name = "Karthik Raja",
        phone = "+91 94432 10987",
        bikeModel = "TVS Raider 125",
        registrationNumber = "KA 51 YZ 3390",
        rating = 4.6,
        totalRides = 340,
        earningsToday = 0.0,
        kycStatus = KycStatus.PENDING,
        isOnline = false,
        vehicleType = VehicleType.BIKE_TAXI
      ),
      Captain(
        id = "CAP-518",
        name = "Imran Khan",
        phone = "+91 98801 54321",
        bikeModel = "Ola S1 Pro (EV)",
        registrationNumber = "KA 04 EV 7112",
        rating = 4.9,
        totalRides = 860,
        earningsToday = 0.0,
        kycStatus = KycStatus.PENDING,
        isOnline = false,
        vehicleType = VehicleType.EV_SCOOTER
      ),
      Captain(
        id = "CAP-340",
        name = "Ganesh Patil",
        phone = "+91 91234 56789",
        bikeModel = "Hero Splendor Plus",
        registrationNumber = "KA 02 AB 9043",
        rating = 4.8,
        totalRides = 3120,
        earningsToday = 1920.0,
        kycStatus = KycStatus.VERIFIED,
        isOnline = true,
        vehicleType = VehicleType.BIKE_TAXI
      ),
      Captain(
        id = "CAP-991",
        name = "Suraj Nambiar",
        phone = "+91 99001 88776",
        bikeModel = "Yamaha FZ-S",
        registrationNumber = "KA 05 PQ 6654",
        rating = 3.2,
        totalRides = 140,
        earningsToday = 0.0,
        kycStatus = KycStatus.REJECTED,
        isOnline = false,
        vehicleType = VehicleType.BIKE_TAXI
      )
    )

    private fun initialAlerts(): List<BroadcastAlert> = listOf(
      BroadcastAlert(
        id = "ALT-1",
        title = "Peak Rain Surge Active",
        message = "Surge multiplier set to 1.3x in East Zone due to light drizzle. Extra incentives applied for captains.",
        time = "15m ago",
        isUrgent = false
      ),
      BroadcastAlert(
        id = "ALT-2",
        title = "Helmet Compliance Drive",
        message = "Mandatory pillion helmet verification active. Remind captains to carry secondary ISI helmet.",
        time = "2h ago",
        isUrgent = true
      )
    )
  }
}

package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AdminViewModel
import com.example.ui.screens.AdminHomeScreen
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.theme.GoZeeBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  private val adminViewModel by viewModels<AdminViewModel>()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        GoZeeAdminApp(viewModel = adminViewModel)
      }
    }
  }
}

@Composable
fun GoZeeAdminApp(
  viewModel: AdminViewModel = viewModel(),
  modifier: Modifier = Modifier
) {
  val isLoggedIn by viewModel.isLoggedIn.collectAsState()

  Surface(
    modifier = modifier.fillMaxSize(),
    color = GoZeeBackground
  ) {
    Crossfade(targetState = isLoggedIn, label = "admin_screen_transition") { loggedIn ->
      if (!loggedIn) {
        AdminLoginScreen(
          onLoginSuccess = { email, pass ->
            viewModel.login(email, pass)
          }
        )
      } else {
        AdminHomeScreen(
          viewModel = viewModel,
          onLogout = {
            viewModel.logout()
          }
        )
      }
    }
  }
}

